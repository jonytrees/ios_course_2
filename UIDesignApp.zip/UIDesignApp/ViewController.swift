//
//  ViewController.swift
//  UIDesignApp
//
//  Created by Евгений Янушкевич on 04.12.2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

